import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPostSchema, insertCommentSchema, insertIdolSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get current user (mock user with id 1)
  app.get("/api/user/me", async (req, res) => {
    try {
      const user = await storage.getUser(1);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get suggested users
  app.get("/api/users/suggested", async (req, res) => {
    try {
      const users = await storage.getSuggestedUsers(5);
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user by ID
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get posts feed
  app.get("/api/posts", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = parseInt(req.query.offset as string) || 0;
      const posts = await storage.getPosts(limit, offset);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get post by ID
  app.get("/api/posts/:id", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const post = await storage.getPostById(postId);
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create new post
  app.post("/api/posts", async (req, res) => {
    try {
      const validatedData = insertPostSchema.parse({
        ...req.body,
        authorId: 1, // Mock current user ID
      });
      const post = await storage.createPost(validatedData);
      res.status(201).json(post);
    } catch (error) {
      res.status(400).json({ message: "Invalid post data" });
    }
  });

  // Get user posts
  app.get("/api/users/:id/posts", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const limit = parseInt(req.query.limit as string) || 10;
      const posts = await storage.getUserPosts(userId, limit);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Toggle like on post
  app.post("/api/posts/:id/like", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = 1; // Mock current user ID
      const result = await storage.toggleLike(userId, postId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Follow user
  app.post("/api/users/:id/follow", async (req, res) => {
    try {
      const followingId = parseInt(req.params.id);
      const followerId = 1; // Mock current user ID
      
      if (followerId === followingId) {
        return res.status(400).json({ message: "Cannot follow yourself" });
      }

      const isAlreadyFollowing = await storage.isFollowing(followerId, followingId);
      
      if (isAlreadyFollowing) {
        await storage.unfollowUser(followerId, followingId);
        res.json({ following: false });
      } else {
        await storage.followUser(followerId, followingId);
        res.json({ following: true });
      }
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get post comments
  app.get("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const comments = await storage.getPostComments(postId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create comment
  app.post("/api/posts/:id/comments", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const validatedData = insertCommentSchema.parse({
        ...req.body,
        postId,
        userId: 1, // Mock current user ID
      });
      const comment = await storage.createComment(validatedData);
      res.status(201).json(comment);
    } catch (error) {
      res.status(400).json({ message: "Invalid comment data" });
    }
  });

  // Get trending topics
  app.get("/api/trending", async (req, res) => {
    try {
      const topics = await storage.getTrendingTopics();
      res.json(topics);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get recent activity
  app.get("/api/activity", async (req, res) => {
    try {
      const userId = 1; // Mock current user ID
      const activity = await storage.getRecentActivity(userId);
      res.json(activity);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Idol-related routes
  // Get all idols
  app.get("/api/idols", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 20;
      const idols = await storage.getIdols(limit);
      res.json(idols);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get idol by ID
  app.get("/api/idols/:id", async (req, res) => {
    try {
      const idolId = parseInt(req.params.id);
      const idol = await storage.getIdolById(idolId);
      if (!idol) {
        return res.status(404).json({ message: "Idol not found" });
      }
      res.json(idol);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get posts for a specific idol
  app.get("/api/idols/:id/posts", async (req, res) => {
    try {
      const idolId = parseInt(req.params.id);
      const limit = parseInt(req.query.limit as string) || 10;
      const posts = await storage.getIdolPosts(idolId, limit);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get user's stanned idols
  app.get("/api/user/stans", async (req, res) => {
    try {
      const userId = 1; // Mock current user ID
      const stannedIdols = await storage.getStannedIdols(userId);
      res.json(stannedIdols);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Toggle stan on idol
  app.post("/api/idols/:id/stan", async (req, res) => {
    try {
      const idolId = parseInt(req.params.id);
      const userId = 1; // Mock current user ID
      const result = await storage.toggleStan(userId, idolId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
