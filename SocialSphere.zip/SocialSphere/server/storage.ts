import {
  users,
  posts,
  idols,
  stans,
  follows,
  likes,
  comments,
  trendingTopics,
  type User,
  type Post,
  type Idol,
  type Stan,
  type InsertUser,
  type InsertPost,
  type InsertIdol,
  type InsertStan,
  type InsertComment,
  type PostWithAuthor,
  type UserWithCounts,
  type TrendingTopic,
  type Activity,
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  getSuggestedUsers(limit?: number): Promise<UserWithCounts[]>;

  // Idols
  getIdols(limit?: number): Promise<Idol[]>;
  getIdolById(id: number): Promise<Idol | undefined>;
  createIdol(idol: InsertIdol): Promise<Idol>;
  getStannedIdols(userId: number): Promise<Idol[]>;

  // Stanning (following idols)
  toggleStan(userId: number, idolId: number): Promise<{ stanned: boolean; stansCount: number }>;
  isStanning(userId: number, idolId: number): Promise<boolean>;

  // Posts
  getPosts(limit?: number, offset?: number, idolId?: number): Promise<PostWithAuthor[]>;
  getPostById(id: number): Promise<PostWithAuthor | undefined>;
  createPost(post: InsertPost): Promise<Post>;
  getUserPosts(userId: number, limit?: number): Promise<PostWithAuthor[]>;
  getIdolPosts(idolId: number, limit?: number): Promise<PostWithAuthor[]>;

  // Social interactions
  toggleLike(userId: number, postId: number): Promise<{ liked: boolean; likesCount: number }>;
  followUser(followerId: number, followingId: number): Promise<boolean>;
  unfollowUser(followerId: number, followingId: number): Promise<boolean>;
  isFollowing(followerId: number, followingId: number): Promise<boolean>;

  // Comments
  getPostComments(postId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;

  // Trending
  getTrendingTopics(): Promise<TrendingTopic[]>;

  // Activity
  getRecentActivity(userId: number): Promise<Activity[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private idols: Map<number, Idol> = new Map();
  private posts: Map<number, Post> = new Map();
  private follows: Map<string, boolean> = new Map();
  private stans: Map<string, boolean> = new Map();
  private likes: Map<string, boolean> = new Map();
  private comments: Map<number, Comment> = new Map();
  private trendingTopics: TrendingTopic[] = [];
  private currentUserId = 1;
  private currentIdolId = 1;
  private currentPostId = 1;
  private currentCommentId = 1;

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Initialize sample users
    const sampleUsers: User[] = [
      {
        id: 1,
        username: "johndoe",
        email: "john@example.com",
        fullName: "John Doe",
        bio: "Senior Developer passionate about creating amazing user experiences",
        title: "Senior Developer",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
        followersCount: 1200,
        followingCount: 856,
        postsCount: 42,
      },
      {
        id: 2,
        username: "sarahjohnson",
        email: "sarah@example.com",
        fullName: "Sarah Johnson",
        bio: "UX Designer crafting digital experiences",
        title: "UX Designer at TechCorp",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
        followersCount: 892,
        followingCount: 423,
        postsCount: 28,
      },
      {
        id: 3,
        username: "mikechen",
        email: "mike@example.com",
        fullName: "Mike Chen",
        bio: "Full Stack Developer building the future",
        title: "Full Stack Developer",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
        followersCount: 567,
        followingCount: 234,
        postsCount: 15,
      },
    ];

    sampleUsers.forEach(user => this.users.set(user.id, user));
    this.currentUserId = 4;

    // Initialize sample idols
    const sampleIdols: Idol[] = [
      {
        id: 1,
        name: "IU",
        imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
        description: "South Korean singer-songwriter and actress",
        category: "K-Pop",
        stansCount: 2500000,
      },
      {
        id: 2,
        name: "BTS",
        imageUrl: "https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
        description: "South Korean boy band",
        category: "K-Pop",
        stansCount: 5000000,
      },
      {
        id: 3,
        name: "BLACKPINK",
        imageUrl: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
        description: "South Korean girl group",
        category: "K-Pop",
        stansCount: 3200000,
      },
      {
        id: 4,
        name: "NewJeans",
        imageUrl: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
        description: "South Korean girl group",
        category: "K-Pop",
        stansCount: 1800000,
      },
    ];

    sampleIdols.forEach(idol => this.idols.set(idol.id, idol));
    this.currentIdolId = 5;

    // Initialize sample posts
    const samplePosts: Post[] = [
      {
        id: 1,
        authorId: 2,
        idolId: 1,
        content: "IU's new song is absolutely breathtaking! 🎵 The vocals, the melody, everything is perfect. She never fails to amaze me with her artistry. This is why she's the queen of K-Pop! #IU #Through_the_Night",
        imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        likesCount: 342,
        commentsCount: 89,
        sharesCount: 45,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      },
      {
        id: 2,
        authorId: 3,
        idolId: 2,
        content: "BTS just announced their world tour dates! 🚀 I'm so excited I can barely contain myself. Army, are you ready? Let's show them our love and support! Purple you! 💜 #BTS #BTSWorldTour #ARMY",
        imageUrl: null,
        likesCount: 1247,
        commentsCount: 234,
        sharesCount: 189,
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
      },
      {
        id: 3,
        authorId: 1,
        idolId: 3,
        content: "BLACKPINK's stage presence is unmatched! 🔥 Watched their latest performance and I'm still getting chills. Lisa's dance, Jennie's rap, Rosé's vocals, and Jisoo's visuals - perfection! #BLACKPINK #BornPink",
        imageUrl: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        likesCount: 856,
        commentsCount: 167,
        sharesCount: 92,
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
      },
      {
        id: 4,
        authorId: 2,
        idolId: 4,
        content: "NewJeans' concept is so fresh and innovative! Their music brings back the nostalgic Y2K vibes while being completely modern. Minji, Hanni, Danielle, Haerin, and Hyein are all so talented! #NewJeans #GetUp",
        imageUrl: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        likesCount: 523,
        commentsCount: 78,
        sharesCount: 34,
        createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000),
      },
    ];

    samplePosts.forEach(post => this.posts.set(post.id, post));
    this.currentPostId = 5;

    // Initialize trending topics
    this.trendingTopics = [
      { id: 1, hashtag: "#WebDevelopment", postsCount: 2400 },
      { id: 2, hashtag: "#UXDesign", postsCount: 1800 },
      { id: 3, hashtag: "#RemoteWork", postsCount: 3100 },
      { id: 4, hashtag: "#AI", postsCount: 5200 },
      { id: 5, hashtag: "#StartupLife", postsCount: 987 },
    ];
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      title: insertUser.title || null,
      bio: insertUser.bio || null,
      avatar: insertUser.avatar || null,
      followersCount: 0,
      followingCount: 0,
      postsCount: 0,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const user = this.users.get(id);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getSuggestedUsers(limit = 5): Promise<UserWithCounts[]> {
    const allUsers = Array.from(this.users.values()).slice(0, limit);
    return allUsers.map(user => ({
      ...user,
      isFollowing: false,
      mutualFriendsCount: Math.floor(Math.random() * 20) + 1,
    }));
  }

  // Idol methods
  async getIdols(limit = 10): Promise<Idol[]> {
    return Array.from(this.idols.values()).slice(0, limit);
  }

  async getIdolById(id: number): Promise<Idol | undefined> {
    return this.idols.get(id);
  }

  async createIdol(insertIdol: InsertIdol): Promise<Idol> {
    const id = this.currentIdolId++;
    const idol: Idol = {
      ...insertIdol,
      id,
      stansCount: 0,
    };
    this.idols.set(id, idol);
    return idol;
  }

  async getStannedIdols(userId: number): Promise<Idol[]> {
    const stannedIdolIds = Array.from(this.stans.keys())
      .filter(key => key.startsWith(`${userId}-`))
      .map(key => parseInt(key.split('-')[1]));
    
    return stannedIdolIds
      .map(idolId => this.idols.get(idolId))
      .filter(idol => idol !== undefined) as Idol[];
  }

  async toggleStan(userId: number, idolId: number): Promise<{ stanned: boolean; stansCount: number }> {
    const stanKey = `${userId}-${idolId}`;
    const isStanned = this.stans.get(stanKey) || false;
    const idol = this.idols.get(idolId);

    if (!idol) throw new Error("Idol not found");

    if (isStanned) {
      this.stans.delete(stanKey);
      idol.stansCount = Math.max(0, (idol.stansCount || 0) - 1);
    } else {
      this.stans.set(stanKey, true);
      idol.stansCount = (idol.stansCount || 0) + 1;
    }

    this.idols.set(idolId, idol);
    return { stanned: !isStanned, stansCount: idol.stansCount };
  }

  async isStanning(userId: number, idolId: number): Promise<boolean> {
    const stanKey = `${userId}-${idolId}`;
    return this.stans.get(stanKey) || false;
  }

  async getPosts(limit = 10, offset = 0, idolId?: number): Promise<PostWithAuthor[]> {
    let allPosts = Array.from(this.posts.values());
    
    if (idolId) {
      allPosts = allPosts.filter(post => post.idolId === idolId);
    }
    
    allPosts = allPosts
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(offset, offset + limit);

    return allPosts.map(post => {
      const author = this.users.get(post.authorId)!;
      const idol = this.idols.get(post.idolId)!;
      return {
        ...post,
        author,
        idol,
        isLiked: this.likes.get(`${1}-${post.id}`) || false,
        isBookmarked: false,
      };
    });
  }

  async getPostById(id: number): Promise<PostWithAuthor | undefined> {
    const post = this.posts.get(id);
    if (!post) return undefined;

    const author = this.users.get(post.authorId)!;
    const idol = this.idols.get(post.idolId)!;
    return {
      ...post,
      author,
      idol,
      isLiked: this.likes.get(`${1}-${post.id}`) || false,
      isBookmarked: false,
    };
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.currentPostId++;
    const post: Post = {
      ...insertPost,
      id,
      imageUrl: insertPost.imageUrl || null,
      likesCount: 0,
      commentsCount: 0,
      sharesCount: 0,
      createdAt: new Date(),
    };
    this.posts.set(id, post);

    // Update user's post count
    const user = this.users.get(insertPost.authorId);
    if (user) {
      this.users.set(user.id, { ...user, postsCount: (user.postsCount || 0) + 1 });
    }

    return post;
  }

  async getUserPosts(userId: number, limit = 10): Promise<PostWithAuthor[]> {
    const userPosts = Array.from(this.posts.values())
      .filter(post => post.authorId === userId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime())
      .slice(0, limit);

    const author = this.users.get(userId)!;
    return userPosts.map(post => {
      const idol = this.idols.get(post.idolId)!;
      return {
        ...post,
        author,
        idol,
        isLiked: this.likes.get(`${1}-${post.id}`) || false,
        isBookmarked: false,
      };
    });
  }

  async getIdolPosts(idolId: number, limit = 10): Promise<PostWithAuthor[]> {
    return this.getPosts(limit, 0, idolId);
  }

  async toggleLike(userId: number, postId: number): Promise<{ liked: boolean; likesCount: number }> {
    const likeKey = `${userId}-${postId}`;
    const isLiked = this.likes.get(likeKey) || false;
    const post = this.posts.get(postId);

    if (!post) throw new Error("Post not found");

    if (isLiked) {
      this.likes.delete(likeKey);
      post.likesCount = Math.max(0, post.likesCount - 1);
    } else {
      this.likes.set(likeKey, true);
      post.likesCount = post.likesCount + 1;
    }

    this.posts.set(postId, post);
    return { liked: !isLiked, likesCount: post.likesCount };
  }

  async followUser(followerId: number, followingId: number): Promise<boolean> {
    const followKey = `${followerId}-${followingId}`;
    this.follows.set(followKey, true);

    // Update follower counts
    const follower = this.users.get(followerId);
    const following = this.users.get(followingId);

    if (follower) {
      this.users.set(followerId, { ...follower, followingCount: follower.followingCount + 1 });
    }
    if (following) {
      this.users.set(followingId, { ...following, followersCount: following.followersCount + 1 });
    }

    return true;
  }

  async unfollowUser(followerId: number, followingId: number): Promise<boolean> {
    const followKey = `${followerId}-${followingId}`;
    this.follows.delete(followKey);

    // Update follower counts
    const follower = this.users.get(followerId);
    const following = this.users.get(followingId);

    if (follower) {
      this.users.set(followerId, { ...follower, followingCount: Math.max(0, follower.followingCount - 1) });
    }
    if (following) {
      this.users.set(followingId, { ...following, followersCount: Math.max(0, following.followersCount - 1) });
    }

    return true;
  }

  async isFollowing(followerId: number, followingId: number): Promise<boolean> {
    const followKey = `${followerId}-${followingId}`;
    return this.follows.get(followKey) || false;
  }

  async getPostComments(postId: number): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime());
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.currentCommentId++;
    const comment: Comment = {
      ...insertComment,
      id,
      createdAt: new Date(),
    };
    this.comments.set(id, comment);

    // Update post comment count
    const post = this.posts.get(insertComment.postId);
    if (post) {
      this.posts.set(post.id, { ...post, commentsCount: post.commentsCount + 1 });
    }

    return comment;
  }

  async getTrendingTopics(): Promise<TrendingTopic[]> {
    return this.trendingTopics;
  }

  async getRecentActivity(userId: number): Promise<Activity[]> {
    // Mock recent activity data
    const activities: Activity[] = [
      {
        id: 1,
        type: 'like',
        user: this.users.get(2)!,
        description: 'liked your post',
        time: '5 minutes ago',
        postId: 1,
      },
      {
        id: 2,
        type: 'follow',
        user: this.users.get(3)!,
        description: 'started following you',
        time: '1 hour ago',
      },
      {
        id: 3,
        type: 'comment',
        user: this.users.get(2)!,
        description: 'commented on your post',
        time: '3 hours ago',
        postId: 2,
      },
    ];

    return activities;
  }
}

export const storage = new MemStorage();
