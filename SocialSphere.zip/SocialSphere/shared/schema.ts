import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  bio: text("bio"),
  title: text("title"),
  avatar: text("avatar"),
  followersCount: integer("followers_count").default(0),
  followingCount: integer("following_count").default(0),
  postsCount: integer("posts_count").default(0),
});

export const idols = pgTable("idols", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  imageUrl: text("image_url").notNull(),
  description: text("description"),
  category: text("category"), // e.g. "K-Pop", "J-Pop", "Actor", etc.
  stansCount: integer("stans_count").default(0),
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  authorId: integer("author_id").notNull(),
  idolId: integer("idol_id").notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  likesCount: integer("likes_count").default(0),
  commentsCount: integer("comments_count").default(0),
  sharesCount: integer("shares_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const stans = pgTable("stans", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  idolId: integer("idol_id").notNull(),
});

export const follows = pgTable("follows", {
  id: serial("id").primaryKey(),
  followerId: integer("follower_id").notNull(),
  followingId: integer("following_id").notNull(),
});

export const likes = pgTable("likes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  postId: integer("post_id").notNull(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  postId: integer("post_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const trendingTopics = pgTable("trending_topics", {
  id: serial("id").primaryKey(),
  hashtag: text("hashtag").notNull(),
  postsCount: integer("posts_count").default(0),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  followersCount: true,
  followingCount: true,
  postsCount: true,
});

export const insertIdolSchema = createInsertSchema(idols).omit({
  id: true,
  stansCount: true,
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  likesCount: true,
  commentsCount: true,
  sharesCount: true,
  createdAt: true,
});

export const insertStanSchema = createInsertSchema(stans).omit({
  id: true,
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertIdol = z.infer<typeof insertIdolSchema>;
export type Idol = typeof idols.$inferSelect;

export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;

export type InsertStan = z.infer<typeof insertStanSchema>;
export type Stan = typeof stans.$inferSelect;

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

export type Follow = typeof follows.$inferSelect;
export type Like = typeof likes.$inferSelect;
export type TrendingTopic = typeof trendingTopics.$inferSelect;

export interface PostWithAuthor extends Post {
  author: User;
  idol: Idol;
  isLiked?: boolean;
  isBookmarked?: boolean;
}

export interface UserWithCounts extends User {
  isFollowing?: boolean;
  mutualFriendsCount?: number;
}

export interface Activity {
  id: number;
  type: 'like' | 'follow' | 'comment';
  user: User;
  description: string;
  time: string;
  postId?: number;
}
