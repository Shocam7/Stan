import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, MessageCircle, Share, Bookmark, MoreHorizontal } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { PostWithAuthor } from "@shared/schema";

interface PostCardProps {
  post: PostWithAuthor;
}

export default function PostCard({ post }: PostCardProps) {
  const [isLiked, setIsLiked] = useState(post.isLiked || false);
  const [isBookmarked, setIsBookmarked] = useState(post.isBookmarked || false);
  const [likesCount, setLikesCount] = useState(post.likesCount || 0);

  const likeMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/posts/${post.id}/like`);
      return response.json();
    },
    onSuccess: (data) => {
      setIsLiked(data.liked);
      setLikesCount(data.likesCount);
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
  });

  const handleLike = () => {
    likeMutation.mutate();
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - new Date(date).getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours === 1) return "1 hour ago";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays === 1) return "1 day ago";
    if (diffInDays < 7) return `${diffInDays} days ago`;
    
    return new Date(date).toLocaleDateString();
  };

  return (
    <Card className="shadow-sm border border-gray-200 relative">
      {/* Idol Image - Top Left Corner */}
      <div className="absolute top-4 left-4 z-10">
        <div className="relative">
          <Avatar className="w-12 h-12 border-2 border-white shadow-lg">
            <AvatarImage src={post.idol?.imageUrl || ""} alt={post.idol?.name || "Idol"} />
            <AvatarFallback className="bg-gradient-to-br from-pink-400 to-purple-500 text-white text-sm font-bold">
              {post.idol?.name?.slice(0, 2) || "ID"}
            </AvatarFallback>
          </Avatar>
          <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-1">
            <Heart className="w-3 h-3 text-red-500 fill-current" />
          </div>
        </div>
      </div>

      <CardContent className="p-6 pt-20">
        {/* Post Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Avatar className="w-10 h-10">
              <AvatarImage src={post.author.avatar || ""} alt={post.author.fullName} />
              <AvatarFallback>
                {post.author.fullName.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div>
              <h4 className="font-semibold text-gray-900">{post.author.fullName}</h4>
              <p className="text-sm text-gray-500">posted about {post.idol?.name}</p>
              <p className="text-xs text-gray-400">{formatTimeAgo(post.createdAt!)}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Post Content */}
        <div className="mb-4">
          <p className="text-gray-900 mb-4 whitespace-pre-wrap">{post.content}</p>
          {post.imageUrl && (
            <img 
              src={post.imageUrl} 
              alt="Post content" 
              className="w-full rounded-lg max-h-96 object-cover"
            />
          )}
        </div>
        
        {/* Post Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="flex space-x-6">
            <Button
              variant="ghost"
              size="sm"
              className={`flex items-center space-x-2 transition-colors ${
                isLiked ? "text-red-500 hover:text-red-600" : "text-gray-600 hover:text-red-500"
              }`}
              onClick={handleLike}
              disabled={likeMutation.isPending}
            >
              <Heart className={`h-4 w-4 ${isLiked ? "fill-current" : ""}`} />
              <span>{likesCount}</span>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 text-gray-600 hover:text-social-blue transition-colors"
            >
              <MessageCircle className="h-4 w-4" />
              <span>{post.commentsCount}</span>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className="flex items-center space-x-2 text-gray-600 hover:text-social-blue transition-colors"
            >
              <Share className="h-4 w-4" />
              <span>Share</span>
            </Button>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            className={`transition-colors ${
              isBookmarked ? "text-yellow-500 hover:text-yellow-600" : "text-gray-600 hover:text-yellow-500"
            }`}
            onClick={handleBookmark}
          >
            <Bookmark className={`h-4 w-4 ${isBookmarked ? "fill-current" : ""}`} />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
