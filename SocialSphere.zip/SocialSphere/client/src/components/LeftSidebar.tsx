import { Link, useLocation } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Home, User, Compass, Users, Calendar } from "lucide-react";
import type { User as UserType } from "@shared/schema";

interface LeftSidebarProps {
  user?: UserType;
}

export default function LeftSidebar({ user }: LeftSidebarProps) {
  const [location] = useLocation();

  const navigationItems = [
    { href: "/", icon: Home, label: "Home", active: location === "/" },
    { href: "/profile", icon: User, label: "Profile", active: location === "/profile" },
    { href: "/explore", icon: Compass, label: "Explore", active: location === "/explore" },
    { href: "/groups", icon: Users, label: "Groups", active: location === "/groups" },
    { href: "/events", icon: Calendar, label: "Events", active: location === "/events" },
  ];

  if (!user) {
    return (
      <aside className="hidden lg:block lg:col-span-3">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-24">
          <div className="animate-pulse">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-gray-200 rounded-full mx-auto mb-3"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-3 bg-gray-200 rounded mb-4"></div>
            </div>
            <div className="space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="h-10 bg-gray-200 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </aside>
    );
  }

  return (
    <aside className="hidden lg:block lg:col-span-3">
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-24">
        {/* User Profile Summary */}
        <div className="text-center mb-6">
          <Avatar className="w-20 h-20 mx-auto mb-3">
            <AvatarImage src={user.avatar || ""} alt={user.fullName} />
            <AvatarFallback className="text-lg font-semibold">
              {user.fullName.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <h3 className="font-semibold text-gray-900">{user.fullName}</h3>
          <p className="text-sm text-gray-500">{user.title}</p>
          <div className="flex justify-center space-x-4 mt-3 text-sm">
            <div className="text-center">
              <div className="font-semibold text-gray-900">
                {user.followersCount >= 1000 
                  ? `${(user.followersCount / 1000).toFixed(1)}K` 
                  : user.followersCount
                }
              </div>
              <div className="text-gray-500">Followers</div>
            </div>
            <div className="text-center">
              <div className="font-semibold text-gray-900">{user.followingCount}</div>
              <div className="text-gray-500">Following</div>
            </div>
          </div>
        </div>
        
        {/* Navigation Menu */}
        <nav className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="ghost"
                  className={`w-full justify-start space-x-3 ${
                    item.active
                      ? "text-social-blue bg-blue-50 hover:bg-blue-50 hover:text-social-blue"
                      : "text-gray-600 hover:text-social-blue hover:bg-gray-50"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className={item.active ? "font-medium" : ""}>{item.label}</span>
                </Button>
              </Link>
            );
          })}
        </nav>
      </div>
    </aside>
  );
}
