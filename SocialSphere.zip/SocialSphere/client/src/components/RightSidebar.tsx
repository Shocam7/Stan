import { useQuery, useMutation } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { UserWithCounts, TrendingTopic, Activity } from "@shared/schema";

export default function RightSidebar() {
  const { data: suggestedUsers, isLoading: usersLoading } = useQuery<UserWithCounts[]>({
    queryKey: ["/api/users/suggested"],
  });

  const { data: trendingTopics, isLoading: trendingLoading } = useQuery<TrendingTopic[]>({
    queryKey: ["/api/trending"],
  });

  const { data: recentActivity, isLoading: activityLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activity"],
  });

  const followMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest("POST", `/api/users/${userId}/follow`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users/suggested"] });
    },
  });

  const handleFollow = (userId: number) => {
    followMutation.mutate(userId);
  };

  return (
    <aside className="hidden lg:block lg:col-span-3">
      <div className="space-y-6">
        {/* Suggested Connections */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Suggested for you</CardTitle>
          </CardHeader>
          <CardContent>
            {usersLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-full animate-pulse"></div>
                      <div className="flex-1">
                        <div className="h-3 bg-gray-200 rounded mb-1 animate-pulse"></div>
                        <div className="h-2 bg-gray-200 rounded animate-pulse"></div>
                      </div>
                    </div>
                    <div className="w-16 h-6 bg-gray-200 rounded animate-pulse"></div>
                  </div>
                ))}
              </div>
            ) : (
              <>
                <div className="space-y-4">
                  {suggestedUsers?.slice(0, 3).map((user) => (
                    <div key={user.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={user.avatar || ""} alt={user.fullName} />
                          <AvatarFallback className="text-sm">
                            {user.fullName.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium text-gray-900 text-sm">{user.fullName}</h4>
                          <p className="text-xs text-gray-500">
                            {user.mutualFriendsCount} mutual connections
                          </p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="bg-social-blue text-white hover:bg-blue-800 text-xs px-3 py-1"
                        onClick={() => handleFollow(user.id)}
                        disabled={followMutation.isPending}
                      >
                        {followMutation.isPending ? "..." : "Follow"}
                      </Button>
                    </div>
                  ))}
                </div>
                <Button 
                  variant="ghost" 
                  className="w-full mt-4 text-social-blue font-medium text-sm hover:underline"
                >
                  See all suggestions
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        {/* Trending Topics */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Trending Topics</CardTitle>
          </CardHeader>
          <CardContent>
            {trendingLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded mb-1"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                {trendingTopics?.map((topic) => (
                  <Button
                    key={topic.id}
                    variant="ghost"
                    className="w-full justify-start p-2 h-auto hover:bg-gray-50 transition-colors"
                  >
                    <div className="text-left">
                      <h4 className="font-medium text-gray-900 text-sm">{topic.hashtag}</h4>
                      <p className="text-xs text-gray-500">{topic.postsCount.toLocaleString()} posts</p>
                    </div>
                  </Button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {activityLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-200 rounded-full animate-pulse"></div>
                    <div className="flex-1">
                      <div className="h-3 bg-gray-200 rounded mb-1 animate-pulse"></div>
                      <div className="h-2 bg-gray-200 rounded animate-pulse"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                {recentActivity?.map((activity) => (
                  <div key={activity.id} className="flex items-center space-x-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={activity.user.avatar || ""} alt={activity.user.fullName} />
                      <AvatarFallback className="text-xs">
                        {activity.user.fullName.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">
                        <span className="font-medium">{activity.user.fullName}</span> {activity.description}
                      </p>
                      <p className="text-xs text-gray-500">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </aside>
  );
}
