import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Image, Video, BarChart3 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Idol } from "@shared/schema";

const postSchema = z.object({
  content: z.string().min(1, "Post content is required").max(2000, "Post content is too long"),
  idolId: z.string().min(1, "Please select an idol"),
});

type PostFormData = z.infer<typeof postSchema>;

interface PostCreationProps {
  onPostCreated: () => void;
}

export default function PostCreation({ onPostCreated }: PostCreationProps) {
  const { toast } = useToast();
  const [currentUser] = useState({
    id: 1,
    fullName: "John Doe",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50",
  });

  // Fetch available idols
  const { data: idols, isLoading: idolsLoading } = useQuery<Idol[]>({
    queryKey: ["/api/idols"],
  });

  const form = useForm<PostFormData>({
    resolver: zodResolver(postSchema),
    defaultValues: {
      content: "",
      idolId: "",
    },
  });

  const createPostMutation = useMutation({
    mutationFn: async (data: PostFormData) => {
      const postData = {
        content: data.content,
        idolId: parseInt(data.idolId),
      };
      const response = await apiRequest("POST", "/api/posts", postData);
      return response.json();
    },
    onSuccess: () => {
      form.reset();
      onPostCreated();
      toast({
        title: "Success",
        description: "Your post has been published!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to publish post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PostFormData) => {
    createPostMutation.mutate(data);
  };

  return (
    <Card className="shadow-sm border border-gray-200 mb-6">
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="flex items-start space-x-4">
              <Avatar className="w-12 h-12">
                <AvatarImage src={currentUser.avatar} alt={currentUser.fullName} />
                <AvatarFallback>
                  {currentUser.fullName.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                {/* Idol Selection */}
                <FormField
                  control={form.control}
                  name="idolId"
                  render={({ field }) => (
                    <FormItem className="mb-4">
                      <FormLabel className="text-sm font-medium text-gray-700">
                        Which idol is this post about?
                      </FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Select an idol..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {idolsLoading ? (
                            <SelectItem value="loading" disabled>Loading idols...</SelectItem>
                          ) : (
                            idols?.map((idol) => (
                              <SelectItem key={idol.id} value={idol.id.toString()}>
                                <div className="flex items-center space-x-2">
                                  <img 
                                    src={idol.imageUrl} 
                                    alt={idol.name}
                                    className="w-5 h-5 rounded-full object-cover"
                                  />
                                  <span>{idol.name}</span>
                                  <span className="text-xs text-gray-500">({idol.category})</span>
                                </div>
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea
                          placeholder="Share your thoughts about this idol..."
                          className="min-h-[80px] resize-none border border-gray-300 rounded-lg focus:ring-2 focus:ring-social-blue focus:border-transparent"
                          {...field}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-between items-center mt-4">
                  <div className="flex space-x-4">
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="flex items-center space-x-2 text-gray-600 hover:text-social-blue transition-colors"
                    >
                      <Image className="h-4 w-4" />
                      <span>Photo</span>
                    </Button>
                    
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="flex items-center space-x-2 text-gray-600 hover:text-social-blue transition-colors"
                    >
                      <Video className="h-4 w-4" />
                      <span>Video</span>
                    </Button>
                    
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="flex items-center space-x-2 text-gray-600 hover:text-social-blue transition-colors"
                    >
                      <BarChart3 className="h-4 w-4" />
                      <span>Poll</span>
                    </Button>
                  </div>
                  
                  <Button
                    type="submit"
                    className="bg-social-blue text-white hover:bg-blue-800 transition-colors px-6"
                    disabled={createPostMutation.isPending || !form.watch("content").trim() || !form.watch("idolId")}
                  >
                    {createPostMutation.isPending ? "Posting..." : "Post"}
                  </Button>
                </div>
              </div>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
