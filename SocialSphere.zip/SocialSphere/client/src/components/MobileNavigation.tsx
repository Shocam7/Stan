import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Home, Search, PlusCircle, Bell, User } from "lucide-react";

export default function MobileNavigation() {
  const [location] = useLocation();

  const navigationItems = [
    { 
      href: "/", 
      icon: Home, 
      label: "Home", 
      active: location === "/" 
    },
    { 
      href: "/explore", 
      icon: Search, 
      label: "Search", 
      active: location === "/explore" 
    },
    { 
      href: "/create", 
      icon: PlusCircle, 
      label: "Create", 
      active: false 
    },
    { 
      href: "/notifications", 
      icon: Bell, 
      label: "Activity", 
      active: location === "/notifications",
      badge: 3
    },
    { 
      href: "/profile", 
      icon: User, 
      label: "Profile", 
      active: location === "/profile" 
    },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 z-40">
      <div className="flex justify-around items-center">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant="ghost"
                size="sm"
                className={`flex flex-col items-center space-y-1 h-auto py-2 px-3 relative ${
                  item.active 
                    ? "text-social-blue" 
                    : "text-gray-400 hover:text-social-blue"
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="text-xs">{item.label}</span>
                {item.badge && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-4 w-4 text-xs p-0 flex items-center justify-center"
                  >
                    {item.badge}
                  </Badge>
                )}
              </Button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
