import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import LeftSidebar from "@/components/LeftSidebar";
import RightSidebar from "@/components/RightSidebar";
import PostCard from "@/components/PostCard";
import MobileNavigation from "@/components/MobileNavigation";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import type { User, PostWithAuthor } from "@shared/schema";

export default function Profile() {
  const params = useParams();
  const userId = params.id ? parseInt(params.id) : 1; // Default to current user

  const { data: currentUser } = useQuery({
    queryKey: ["/api/user/me"],
  });

  const { data: profileUser, isLoading: userLoading } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
  });

  const { data: userPosts, isLoading: postsLoading } = useQuery<PostWithAuthor[]>({
    queryKey: [`/api/users/${userId}/posts`],
  });

  if (userLoading) {
    return (
      <div className="min-h-screen bg-social-bg">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="animate-pulse">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
              <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
                <div className="w-32 h-32 bg-gray-200 rounded-full"></div>
                <div className="flex-1 text-center md:text-left">
                  <div className="h-8 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <MobileNavigation />
      </div>
    );
  }

  if (!profileUser) {
    return (
      <div className="min-h-screen bg-social-bg">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Card>
            <CardContent className="pt-6 text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">User Not Found</h1>
              <p className="text-gray-600">The user you're looking for doesn't exist.</p>
            </CardContent>
          </Card>
        </div>
        <MobileNavigation />
      </div>
    );
  }

  const isOwnProfile = currentUser?.id === profileUser.id;

  return (
    <div className="min-h-screen bg-social-bg">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <LeftSidebar user={currentUser} />
          
          <main className="lg:col-span-6">
            {/* Profile Header */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
              <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
                <Avatar className="w-32 h-32">
                  <AvatarImage 
                    src={profileUser.avatar || ""} 
                    alt={profileUser.fullName}
                  />
                  <AvatarFallback className="text-2xl font-semibold">
                    {profileUser.fullName.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1 text-center md:text-left">
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">
                    {profileUser.fullName}
                  </h1>
                  <p className="text-lg text-social-gray mb-2">
                    {profileUser.title}
                  </p>
                  {profileUser.bio && (
                    <p className="text-gray-600 mb-4 max-w-2xl">
                      {profileUser.bio}
                    </p>
                  )}
                  
                  <div className="flex justify-center md:justify-start space-x-6 mb-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-gray-900">
                        {profileUser.postsCount}
                      </div>
                      <div className="text-sm text-gray-500">Posts</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-gray-900">
                        {profileUser.followersCount.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-500">Followers</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-gray-900">
                        {profileUser.followingCount}
                      </div>
                      <div className="text-sm text-gray-500">Following</div>
                    </div>
                  </div>
                  
                  {!isOwnProfile && (
                    <Button className="bg-social-blue hover:bg-blue-800 text-white">
                      Follow
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {/* Posts Section */}
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                {isOwnProfile ? 'Your Posts' : `${profileUser.fullName.split(' ')[0]}'s Posts`}
              </h2>
              
              {postsLoading ? (
                <div className="space-y-6">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                      <div className="animate-pulse">
                        <div className="flex items-center space-x-3 mb-4">
                          <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-gray-200 rounded mb-1"></div>
                            <div className="h-3 bg-gray-200 rounded"></div>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="h-4 bg-gray-200 rounded"></div>
                          <div className="h-4 bg-gray-200 rounded"></div>
                          <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : userPosts && userPosts.length > 0 ? (
                <div className="space-y-6">
                  {userPosts.map((post) => (
                    <PostCard key={post.id} post={post} />
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <p className="text-gray-600">
                      {isOwnProfile 
                        ? "You haven't posted anything yet." 
                        : `${profileUser.fullName.split(' ')[0]} hasn't posted anything yet.`
                      }
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </main>
          
          <RightSidebar />
        </div>
      </div>
      
      <MobileNavigation />
    </div>
  );
}
