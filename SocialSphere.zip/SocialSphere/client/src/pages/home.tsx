import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import LeftSidebar from "@/components/LeftSidebar";
import RightSidebar from "@/components/RightSidebar";
import PostCreation from "@/components/PostCreation";
import PostCard from "@/components/PostCard";
import MobileNavigation from "@/components/MobileNavigation";
import { Button } from "@/components/ui/button";
import type { PostWithAuthor } from "@shared/schema";
import { useState } from "react";

export default function Home() {
  const [filter, setFilter] = useState("all");
  
  const { data: posts, isLoading, refetch } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/posts"],
  });

  const { data: currentUser } = useQuery({
    queryKey: ["/api/user/me"],
  });

  const handlePostCreated = () => {
    refetch();
  };

  const filterButtons = [
    { key: "all", label: "All Posts" },
    { key: "following", label: "Following" },
    { key: "trending", label: "Trending" },
    { key: "recent", label: "Recent" },
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-social-bg">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <aside className="hidden lg:block lg:col-span-3">
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="animate-pulse">
                  <div className="w-20 h-20 bg-gray-200 rounded-full mx-auto mb-3"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-4"></div>
                </div>
              </div>
            </aside>
            <main className="lg:col-span-6">
              <div className="space-y-6">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                    <div className="animate-pulse">
                      <div className="flex items-center space-x-3 mb-4">
                        <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-4 bg-gray-200 rounded mb-1"></div>
                          <div className="h-3 bg-gray-200 rounded"></div>
                        </div>
                      </div>
                      <div className="space-y-2 mb-4">
                        <div className="h-4 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded"></div>
                        <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </main>
            <aside className="hidden lg:block lg:col-span-3">
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded mb-4"></div>
                  <div className="space-y-3">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div key={i} className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                        <div className="flex-1">
                          <div className="h-3 bg-gray-200 rounded mb-1"></div>
                          <div className="h-2 bg-gray-200 rounded"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </div>
        <MobileNavigation />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-social-bg">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <LeftSidebar user={currentUser} />
          
          <main className="lg:col-span-6">
            <PostCreation onPostCreated={handlePostCreated} />
            
            {/* Filter Bar */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
              <div className="flex flex-wrap gap-2">
                {filterButtons.map((button) => (
                  <Button
                    key={button.key}
                    variant={filter === button.key ? "default" : "secondary"}
                    size="sm"
                    className={filter === button.key 
                      ? "bg-social-blue text-white hover:bg-blue-800" 
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }
                    onClick={() => setFilter(button.key)}
                  >
                    {button.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Posts Feed */}
            <div className="space-y-6">
              {posts?.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>

            {/* Load More */}
            <div className="text-center py-8">
              <Button 
                variant="outline" 
                className="bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
              >
                Load More Posts
              </Button>
            </div>
          </main>
          
          <RightSidebar />
        </div>
      </div>
      
      <MobileNavigation />
    </div>
  );
}
