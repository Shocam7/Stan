import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import LeftSidebar from "@/components/LeftSidebar";
import RightSidebar from "@/components/RightSidebar";
import PostCard from "@/components/PostCard";
import MobileNavigation from "@/components/MobileNavigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Compass, TrendingUp } from "lucide-react";
import type { PostWithAuthor, TrendingTopic } from "@shared/schema";

export default function Explore() {
  const { data: currentUser } = useQuery({
    queryKey: ["/api/user/me"],
  });

  const { data: posts, isLoading: postsLoading } = useQuery<PostWithAuthor[]>({
    queryKey: ["/api/posts"],
  });

  const { data: trendingTopics, isLoading: trendingLoading } = useQuery<TrendingTopic[]>({
    queryKey: ["/api/trending"],
  });

  return (
    <div className="min-h-screen bg-social-bg">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <LeftSidebar user={currentUser} />
          
          <main className="lg:col-span-6">
            {/* Explore Header */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
              <div className="flex items-center space-x-3 mb-4">
                <Compass className="h-8 w-8 text-social-blue" />
                <h1 className="text-2xl font-bold text-gray-900">Explore</h1>
              </div>
              
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search posts, people, topics..."
                  className="pl-10 rounded-full border-gray-300 focus:border-social-blue focus:ring-social-blue"
                />
              </div>
            </div>

            {/* Trending Topics Section */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-social-blue" />
                  <span>Trending Topics</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {trendingLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-4 bg-gray-200 rounded mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-1/3"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {trendingTopics?.map((topic) => (
                      <Button
                        key={topic.id}
                        variant="ghost"
                        className="justify-start h-auto p-3 hover:bg-blue-50 hover:text-social-blue"
                      >
                        <div className="text-left">
                          <div className="font-semibold text-sm">
                            {topic.hashtag}
                          </div>
                          <div className="text-xs text-gray-500">
                            {topic.postsCount.toLocaleString()} posts
                          </div>
                        </div>
                      </Button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Popular Posts */}
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                <span>Popular Posts</span>
              </h2>
              
              {postsLoading ? (
                <div className="space-y-6">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                      <div className="animate-pulse">
                        <div className="flex items-center space-x-3 mb-4">
                          <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-gray-200 rounded mb-1"></div>
                            <div className="h-3 bg-gray-200 rounded"></div>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div className="h-4 bg-gray-200 rounded"></div>
                          <div className="h-4 bg-gray-200 rounded"></div>
                          <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-6">
                  {posts?.slice(0, 5).map((post) => (
                    <PostCard key={post.id} post={post} />
                  ))}
                </div>
              )}
            </div>
          </main>
          
          <RightSidebar />
        </div>
      </div>
      
      <MobileNavigation />
    </div>
  );
}
