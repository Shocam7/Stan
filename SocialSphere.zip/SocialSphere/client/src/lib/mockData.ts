import type { User, PostWithAuthor, UserWithCounts, TrendingTopic, Activity } from "@shared/schema";

export const mockUsers: User[] = [
  {
    id: 1,
    username: "johndoe",
    email: "john@example.com",
    fullName: "John Doe",
    bio: "Senior Developer passionate about creating amazing user experiences",
    title: "Senior Developer",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
    followersCount: 1200,
    followingCount: 856,
    postsCount: 42,
  },
  {
    id: 2,
    username: "sarahjohnson",
    email: "sarah@example.com",
    fullName: "Sarah Johnson",
    bio: "UX Designer crafting digital experiences",
    title: "UX Designer at TechCorp",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b47c?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
    followersCount: 892,
    followingCount: 423,
    postsCount: 28,
  },
  {
    id: 3,
    username: "mikechen",
    email: "mike@example.com",
    fullName: "Mike Chen",
    bio: "Full Stack Developer building the future",
    title: "Full Stack Developer",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120",
    followersCount: 567,
    followingCount: 234,
    postsCount: 15,
  },
];

export const mockPosts: PostWithAuthor[] = [
  {
    id: 1,
    authorId: 2,
    content: "Just finished an amazing design sprint with the team! 🎨 We're working on a new user onboarding flow that's going to make our app so much more intuitive. Can't wait to share the results with everyone. What's your favorite part of the design process?",
    imageUrl: "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    likesCount: 24,
    commentsCount: 8,
    sharesCount: 3,
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    author: mockUsers[1],
    isLiked: false,
    isBookmarked: false,
  },
  {
    id: 2,
    authorId: 3,
    content: "🚀 Excited to share that our team just deployed a major update to our platform! We've improved performance by 40% and added some cool new features. The best part? We managed to reduce our bundle size while adding functionality. #webdev #performance",
    imageUrl: null,
    likesCount: 47,
    commentsCount: 12,
    sharesCount: 8,
    createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000),
    author: mockUsers[2],
    isLiked: true,
    isBookmarked: true,
  },
  {
    id: 3,
    authorId: 1,
    content: "Attended an incredible tech conference today! 📱 The keynote on AI and user experience was mind-blowing. Met so many talented professionals and learned about the latest trends in product development. Networking events like these are pure gold!",
    imageUrl: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    likesCount: 31,
    commentsCount: 15,
    sharesCount: 5,
    createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000),
    author: mockUsers[0],
    isLiked: false,
    isBookmarked: false,
  },
];

export const mockSuggestedUsers: UserWithCounts[] = [
  {
    ...mockUsers[0],
    isFollowing: false,
    mutualFriendsCount: 12,
  },
  {
    ...mockUsers[1],
    isFollowing: false,
    mutualFriendsCount: 8,
  },
  {
    ...mockUsers[2],
    isFollowing: false,
    mutualFriendsCount: 15,
  },
];

export const mockTrendingTopics: TrendingTopic[] = [
  { id: 1, hashtag: "#WebDevelopment", postsCount: 2400 },
  { id: 2, hashtag: "#UXDesign", postsCount: 1800 },
  { id: 3, hashtag: "#RemoteWork", postsCount: 3100 },
  { id: 4, hashtag: "#AI", postsCount: 5200 },
  { id: 5, hashtag: "#StartupLife", postsCount: 987 },
];

export const mockRecentActivity: Activity[] = [
  {
    id: 1,
    type: 'like',
    user: mockUsers[1],
    description: 'liked your post',
    time: '5 minutes ago',
    postId: 1,
  },
  {
    id: 2,
    type: 'follow',
    user: mockUsers[2],
    description: 'started following you',
    time: '1 hour ago',
  },
  {
    id: 3,
    type: 'comment',
    user: mockUsers[1],
    description: 'commented on your post',
    time: '3 hours ago',
    postId: 2,
  },
];
